//@ts-nocheck
// import Head from 'next/head'
import Layout from '../component/layout'
import Jumbotron from '../component/jumbotron'
// import Header from '../component/header'

export default function Home() {
  return (
    <div>
      <Layout>
        <Jumbotron />
      </Layout>
    </div>
  )
}
